// Initialize default admin user for first-time setup
(function initializeDefaultAdmin() {
    const existingUsers = JSON.parse(localStorage.getItem('chillzoneUsers')) || [];
    
    // Check if admin user already exists
    const adminExists = existingUsers.some(user => user.username === 'admin');
    
    if (!adminExists) {
        // Create default admin user
        const defaultAdmin = {
            id: Date.now(),
            fullName: 'System Administrator',
            email: 'admin@chillzone.games',
            username: 'admin',
            password: btoa('admin123' + 'chillzone_salt'), // Hashed password
            createdAt: new Date().toISOString(),
            isActive: true,
            isAdmin: true
        };
        
        existingUsers.push(defaultAdmin);
        localStorage.setItem('chillzoneUsers', JSON.stringify(existingUsers));
        
        console.log('Default admin user created: username: admin, password: admin123');
    }
})();
