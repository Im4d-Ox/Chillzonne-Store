// User Session Management System for Main Website

class UserSessionManager {
    constructor() {
        this.initializeSession();
        this.updateNavigation();
        this.setupEventListeners();
    }
    
    initializeSession() {
        // Check if user is logged in
        const isLoggedIn = sessionStorage.getItem('userLoggedIn') === 'true';
        const isAdmin = sessionStorage.getItem('isAdmin') === 'true';
        
        if (!isLoggedIn) {
            // User is not logged in, show auth links
            this.showAuthLinks();
        } else {
            // User is logged in, show user menu
            this.showUserMenu();
            
            // Show admin link if user is admin
            if (isAdmin) {
                this.showAdminLink();
            }
        }
    }
    
    updateNavigation() {
        const authLinks = document.getElementById('authLinks');
        const userMenu = document.getElementById('userMenu');
        const adminLink = document.getElementById('adminLink');
        const userProfile = document.getElementById('userProfile');
        
        if (!authLinks || !userMenu || !adminLink) return;
        
        // Update user profile link text
        const username = sessionStorage.getItem('userUsername');
        if (username && userProfile) {
            userProfile.textContent = username;
            userProfile.href = '#profile';
        }
        
        // Add logout functionality
        if (userProfile) {
            userProfile.addEventListener('click', (e) => {
                e.preventDefault();
                this.showUserDropdown();
            });
        }
    }
    
    showAuthLinks() {
        const authLinks = document.getElementById('authLinks');
        const userMenu = document.getElementById('userMenu');
        const adminLink = document.getElementById('adminLink');
        
        if (authLinks) authLinks.style.display = 'flex';
        if (userMenu) userMenu.style.display = 'none';
        if (adminLink) adminLink.style.display = 'none';
    }
    
    showUserMenu() {
        const authLinks = document.getElementById('authLinks');
        const userMenu = document.getElementById('userMenu');
        
        if (authLinks) authLinks.style.display = 'none';
        if (userMenu) userMenu.style.display = 'block';
    }
    
    showAdminLink() {
        const adminLink = document.getElementById('adminLink');
        if (adminLink) adminLink.style.display = 'block';
    }
    
    showUserDropdown() {
        // Create dropdown menu
        const existingDropdown = document.getElementById('userDropdown');
        if (existingDropdown) {
            existingDropdown.remove();
            return;
        }
        
        const dropdown = document.createElement('div');
        dropdown.id = 'userDropdown';
        dropdown.style.cssText = `
            position: absolute;
            top: 100%;
            right: 0;
            background: rgba(0, 0, 0, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 10px 0;
            min-width: 150px;
            backdrop-filter: blur(10px);
            z-index: 1000;
            margin-top: 5px;
        `;
        
        const userFullName = sessionStorage.getItem('userFullName');
        const userEmail = sessionStorage.getItem('userEmail');
        const isAdmin = sessionStorage.getItem('isAdmin') === 'true';
        
        dropdown.innerHTML = `
            <div style="padding: 10px 20px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);">
                <div style="color: var(--text-light); font-size: 12px; font-weight: 600;">${userFullName}</div>
                <div style="color: var(--text-muted); font-size: 11px;">${userEmail}</div>
                ${isAdmin ? '<div style="color: var(--accent); font-size: 10px; margin-top: 5px;">Administrator</div>' : ''}
            </div>
            <a href="profile.html" style="display: block; padding: 10px 20px; color: var(--text-light); text-decoration: none; font-size: 13px; transition: background 0.3s;">My Profile</a>
            <a href="settings.html" style="display: block; padding: 10px 20px; color: var(--text-light); text-decoration: none; font-size: 13px; transition: background 0.3s;">Settings</a>
            <a href="#" onclick="UserSessionManager.logout()" style="display: block; padding: 10px 20px; color: var(--accent); text-decoration: none; font-size: 13px; transition: background 0.3s;">Logout</a>
        `;
        
        // Add hover effects
        dropdown.querySelectorAll('a').forEach(link => {
            link.addEventListener('mouseenter', () => {
                link.style.background = 'rgba(255, 255, 255, 0.05)';
            });
            link.addEventListener('mouseleave', () => {
                link.style.background = 'transparent';
            });
        });
        
        // Close dropdown when clicking outside
        const closeDropdown = (e) => {
            if (!dropdown.contains(e.target) && !userMenu.contains(e.target)) {
                dropdown.remove();
                document.removeEventListener('click', closeDropdown);
            }
        };
        
        setTimeout(() => {
            document.addEventListener('click', closeDropdown);
        }, 100);
        
        // Position dropdown relative to user menu
        const userMenu = document.getElementById('userMenu');
        if (userMenu) {
            const rect = userMenu.getBoundingClientRect();
            dropdown.style.position = 'fixed';
            dropdown.style.top = rect.bottom + 'px';
            dropdown.style.right = (window.innerWidth - rect.right) + 'px';
        }
        
        document.body.appendChild(dropdown);
        
        // Close dropdown when clicking outside
        const closeDropdownHandler = (e) => {
            if (!dropdown.contains(e.target) && !userMenu.contains(e.target)) {
                dropdown.remove();
                document.removeEventListener('click', closeDropdownHandler);
            }
        };
        
        setTimeout(() => {
            document.addEventListener('click', closeDropdownHandler);
        }, 100);
    }
    
    setupEventListeners() {
        // Listen for storage changes (for multi-tab support)
        window.addEventListener('storage', (e) => {
            if (e.key === 'userLoggedIn' || e.key === 'isAdmin') {
                this.initializeSession();
            }
        });
    }
    
    static logout() {
        // Clear session
        sessionStorage.removeItem('userLoggedIn');
        sessionStorage.removeItem('userUsername');
        sessionStorage.removeItem('userFullName');
        sessionStorage.removeItem('userEmail');
        sessionStorage.removeItem('userId');
        sessionStorage.removeItem('isAdmin');
        
        // Remove dropdown if exists
        const dropdown = document.getElementById('userDropdown');
        if (dropdown) dropdown.remove();
        
        // Reload page to update navigation
        window.location.reload();
    }
    
    static getCurrentUser() {
        return {
            isLoggedIn: sessionStorage.getItem('userLoggedIn') === 'true',
            username: sessionStorage.getItem('userUsername'),
            fullName: sessionStorage.getItem('userFullName'),
            email: sessionStorage.getItem('userEmail'),
            userId: sessionStorage.getItem('userId'),
            isAdmin: sessionStorage.getItem('isAdmin') === 'true'
        };
    }
    
    static requireAuth() {
        const user = UserSessionManager.getCurrentUser();
        if (!user.isLoggedIn) {
            window.location.href = 'login.html';
            return false;
        }
        return true;
    }
    
    static requireAdmin() {
        const user = UserSessionManager.getCurrentUser();
        if (!user.isLoggedIn || !user.isAdmin) {
            window.location.href = 'login.html';
            return false;
        }
        return true;
    }
}

// Initialize session manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new UserSessionManager();
});

// Make it globally available
window.UserSessionManager = UserSessionManager;
